#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
public static class OpenDataFolder {
  [MenuItem("Tools/Open Persistent Data Folder")]
  public static void OpenPersistent() {
    var path = Application.persistentDataPath;
    Debug.Log("Opening: " + path);
    EditorUtility.RevealInFinder(path);
  }
}
#endif
