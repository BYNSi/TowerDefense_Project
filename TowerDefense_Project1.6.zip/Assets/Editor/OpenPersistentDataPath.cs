#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class OpenPersistentDataPath
{
    [MenuItem("Tools/Open PersistentDataPath")]
    public static void OpenPDP()
    {
        EditorUtility.RevealInFinder(Application.persistentDataPath);
        Debug.Log("Opened: " + Application.persistentDataPath);
    }
}
#endif
