using UnityEngine;

[CreateAssetMenu(fileName = "ExperimentConfig", menuName = "TD/Experiment Config", order = 0)]
public class ExperimentConfig : ScriptableObject
{
    [Header("Independent Variables")]
    [Tooltip("Turret target-selection policy for this run (RQ1).")]
    public TargetingMode targetingMode = TargetingMode.Nearest;

    [Tooltip("Build/upgrade allocation policy (RQ2).")]
    public BuildPlan buildPlan = BuildPlan.None;

    [Header("Reproducibility & Logging")]
    [Tooltip("Random seed passed to Random.InitState(...) at the start of a run.")]
    public int randomSeed = 12345;

    [Tooltip("Written to the 'condition' column in the CSV (e.g., RQ1-Nearest, RQ1-Closest, RQ2-U, RQ2-S).")]
    public string conditionLabel = "RQ1-Nearest";

    [Tooltip("CSV file name saved under Application.persistentDataPath.")]
    public string csvFileName = "rq2_results.csv";

    [Header("RQ2 — Build Plan Details")]
    [Tooltip("Base turret used by both plans when placing towers. Leave empty to use BuildManager.StandardTurretData.")]
    public TurretData baseTurret;

    [Tooltip("Upgrade-focused: place at least this many L1 towers before upgrading.")]
    public int upgradeFocusedInit = 2;   

    [Tooltip("Spread-focused: target number of L1 towers to place first.")]
    public int spreadFocusedCount = 4;   

    [Tooltip("Reserved (not required).")]
    public float upgradeTime = 5f;

    private void OnValidate()
    {
        if (!string.IsNullOrEmpty(csvFileName) && !csvFileName.EndsWith(".csv"))
            csvFileName += ".csv";
        if (upgradeFocusedInit < 1) upgradeFocusedInit = 1;
        if (spreadFocusedCount < 1) spreadFocusedCount = 1;
        if (upgradeTime < 0f) upgradeTime = 0f;
    }
}

public enum TargetingMode { Nearest, ClosestToExit }
public enum BuildPlan { None, UpgradeFocused, SpreadFocused }
