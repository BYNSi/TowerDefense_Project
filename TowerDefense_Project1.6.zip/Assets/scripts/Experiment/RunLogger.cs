
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;
using System.Text;
using System.Globalization;

public class RunLogger : MonoBehaviour
{
    public static RunLogger I { get; private set; }

    string _csvPath;
    string _condition = "UNSET";
    string _map = "";
    string _plan = "";
    string _targeting = "";
    int    _seed = 0;

    float  _startTime;
    int    _leaks;
    double _totalDamage;
    int    _placements;
    int    _upgrades;
    int    _goldSpent;

    void Awake()
    {
        if (I != null && I != this) { Destroy(gameObject); return; }
        I = this;
        DontDestroyOnLoad(gameObject);
        _startTime = Time.time;
    }


    public void Init(string condition, string csvFileName)
    {
        _startTime   = Time.time;
        _leaks       = 0;
        _totalDamage = 0;
        _placements  = 0;
        _upgrades    = 0;
        _goldSpent   = 0;

        _condition  = string.IsNullOrEmpty(condition) ? "UNSET" : condition;
        if (string.IsNullOrEmpty(csvFileName)) csvFileName = "results.csv";
        if (!csvFileName.EndsWith(".csv"))     csvFileName += ".csv";
        _csvPath = Path.Combine(Application.persistentDataPath, csvFileName);

        _map = SceneManager.GetActiveScene().name;
        var cfg = GameManager.Instance != null ? GameManager.Instance.config : null;
        if (cfg != null)
        {
            _plan      = cfg.buildPlan.ToString();
            _targeting = cfg.targetingMode.ToString();
            _seed      = cfg.randomSeed;
        }
        else
        {
            _plan = "(none)"; _targeting = "(default)"; _seed = 0;
        }

        if (!File.Exists(_csvPath))
        {
            File.WriteAllText(_csvPath,
                "datetime,map,condition,targeting_mode,plan,seed,placements,upgrades,gold_spent,result,leaks,duration,totalDamage\n",
                Encoding.UTF8);
        }

        Debug.Log("[RunLogger] writing to: " + _csvPath);
    }

    public void AddLeak()                    { _leaks++; }
    public void AddDamage(double amount)     { if (amount > 0) _totalDamage += amount; }
    public void CountPlacement(int cost)     { _placements++; _goldSpent += Mathf.Max(0, cost); }
    public void CountUpgrade(int cost)       { _upgrades++;  _goldSpent += Mathf.Max(0, cost); }

    public void FinalizeAndWrite(string result)
    {
        float duration = Time.time - _startTime;
        string line =
            $"{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}," +
            $"{_map}," +
            $"{_condition}," +
            $"{_targeting}," +
            $"{_plan}," +
            $"{_seed}," +
            $"{_placements}," +
            $"{_upgrades}," +
            $"{_goldSpent}," +
            $"{result}," +
            $"{_leaks}," +
            $"{duration.ToString(CultureInfo.InvariantCulture)}," +
            $"{_totalDamage.ToString(CultureInfo.InvariantCulture)}\n";

        try   { File.AppendAllText(_csvPath, line, Encoding.UTF8); }
        catch (System.Exception e) { Debug.LogWarning("[RunLogger] write failed: " + e.Message); }

        Debug.Log("[RunLogger] " + line);
    }
}
