using System.Collections.Generic;
using UnityEngine;

namespace RQ2
{
    public class UpgradeFocusedPlanner : IRQ2BuildPlanner
    {
        private RQ2Context ctx;
        private int kEarly; // 可扩展：前期优先的关键槽位数（此实现按排序自然满足）
        private int t0;     // 开局先放多少座 1级塔
        private int cursorPlace = 0;

        private readonly HashSet<MapCube> occupied = new();
        private readonly HashSet<MapCube> upgraded = new();

        private int placements = 0, upgrades = 0, spent = 0;
        private bool done = false;

        public UpgradeFocusedPlanner(int kEarly = 2, int t0 = 2)
        { this.kEarly = Mathf.Max(0,kEarly); this.t0 = Mathf.Max(0,t0); }

        public void Init(RQ2Context ctx) { this.ctx = ctx; }

        public bool TryNextAction()
        {
            if (done) return false;

            // 1) 开局先放 t0 座
            while (placements < t0 && cursorPlace < ctx.Slots.Count)
            {
                var slot = ctx.Slots[cursorPlace++];
                if (RQ2Common.TryPlace(slot, ctx.Turret, ref ctx.Budget, occupied))
                { placements++; spent = 1000 - ctx.Budget; return true; }
            }

            // 2) 优先把已放的塔升级
            foreach (var slot in occupied)
            {
                if (RQ2Common.TryUpgrade(slot, ctx.Turret, ref ctx.Budget, upgraded))
                { upgrades++; spent = 1000 - ctx.Budget; return true; }
            }

            // 3) 仍有钱则继续放新塔
            while (cursorPlace < ctx.Slots.Count)
            {
                var slot = ctx.Slots[cursorPlace++];
                if (RQ2Common.TryPlace(slot, ctx.Turret, ref ctx.Budget, occupied))
                { placements++; spent = 1000 - ctx.Budget; return true; }
            }

            done = true; return false;
        }

        public bool IsDone => done;
        public int Placements => placements;
        public int Upgrades => upgrades;
        public int GoldSpent => spent;
    }
}
