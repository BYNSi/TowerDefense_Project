using System.Collections.Generic;

namespace RQ2
{
    public enum PlanType { UpgradeFocused, SpreadFocused }

    public class RQ2Context
    {
        public System.Collections.Generic.List<MapCube> Slots;
        public TurretData Turret;
        public int Budget;
        public System.Random Rng;
        public string MapName;
    }

    public interface IRQ2BuildPlanner
    {
        void Init(RQ2Context ctx);
        bool TryNextAction();    
        bool IsDone { get; }
        int Placements { get; }
        int Upgrades { get; }
        int GoldSpent { get; }
    }
}
