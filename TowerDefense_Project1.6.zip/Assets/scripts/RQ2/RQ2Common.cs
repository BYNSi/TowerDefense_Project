using System.Collections.Generic;
using UnityEngine;

namespace RQ2
{
    public static class RQ2Common
    {
        public static List<MapCube> GetSortedSlots()
        {
            var all = GameObject.FindObjectsOfType<MapCube>();
            var list = new List<MapCube>();
            foreach (var m in all)
            {
                if (m == null) continue;
                if (m.gameObject.CompareTag("Road")) continue;
                list.Add(m);
            }
            list.Sort((a, b) =>
            {
                float da = DistanceToPath(a.transform.position);
                float db = DistanceToPath(b.transform.position);
                return da.CompareTo(db);
            });
            return list;
        }

        public static float DistanceToPath(Vector3 pos)
        {
            if (Waypoints.Instance == null) return 1e9f;
            float best = float.MaxValue;
            for (int i = 0; i < Waypoints.Instance.Count; i++)
            {
                var w = Waypoints.Instance.GetWaypoint(i);
                float d = Vector3.Distance(pos, w);
                if (d < best) best = d;
            }
            return best;
        }

        public static bool TryPlace(MapCube cube, TurretData td, ref int budget, HashSet<MapCube> occupied)
        {
            if (cube == null || td == null) return false;
            if (occupied.Contains(cube)) return false;
            if (budget < td.cost) return false;

            var bm = BuildManager.Instance;
            if (bm == null) { Debug.LogWarning("BuildManager not found"); return false; }

            var bak = bm.selectedTurretData;
            bm.selectedTurretData = td;
            cube.gameObject.SendMessage("BuildTurret", SendMessageOptions.DontRequireReceiver);
            bm.selectedTurretData = bak;

            occupied.Add(cube);
            budget -= td.cost;
            RunRecorder.CountPlacement(td.cost);
            return true;
        }

        public static bool TryUpgrade(MapCube cube, TurretData td, ref int budget, HashSet<MapCube> upgraded)
        {
            if (cube == null || td == null) return false;
            if (upgraded.Contains(cube)) return false;
            if (budget < td.costUpgrade) return false;

            cube.gameObject.SendMessage("OnTurretUpgrade", SendMessageOptions.DontRequireReceiver);
            upgraded.Add(cube);
            budget -= td.costUpgrade;
            RunRecorder.CountUpgrade(td.costUpgrade);
            return true;
        }
    }
}
