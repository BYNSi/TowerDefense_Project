using UnityEngine;
using UnityEngine.SceneManagement;

namespace RQ2
{
    /// <summary>
    /// 开局读取 GameManager.config（与 RQ1 同一路线），设置目标锁定/种子，
    /// 若选择了 Build Plan，则执行 RQ2 的建造/升级，并写入一行 BUILD 记录。
    /// </summary>
    [DefaultExecutionOrder(-1000)]
    public class RQ2Executor : MonoBehaviour
    {
        public int kEarly = 2; // 升级优先：可外部覆盖
        private void Start()
        {
            var gm = GameManager.Instance;
            if (gm == null || gm.config == null) return;
            var cfg = gm.config;

            // 1) RQ1 设置：目标锁定 + 种子
            UnityEngine.Random.InitState(cfg.randomSeed);
            Turret.GlobalMode = (cfg.targetingMode == TargetingMode.Nearest)
                ? Turret.TargetingMode.Nearest
                : Turret.TargetingMode.ClosestToExit;

            // 2) 记录器起一条新 run
            RunRecorder.StartNew(cfg);

            // 3) 若未选择 RQ2 方案，则不做自动建造
            if (cfg.buildPlan == BuildPlan.None) return;

            var td = (cfg.baseTurret != null) ? cfg.baseTurret : BuildManager.Instance?.StandardTurretData;
            if (td == null) { Debug.LogError("[RQ2] TurretData 未设置"); return; }

            var ctx = new RQ2Context {
                Slots = RQ2Common.GetSortedSlots(),
                Turret = td,
                Budget = 1000,
                Rng = new System.Random(cfg.randomSeed),
                MapName = SceneManager.GetActiveScene().name
            };

            IRQ2BuildPlanner planner =
                (cfg.buildPlan == BuildPlan.UpgradeFocused)
                ? new UpgradeFocusedPlanner(kEarly: kEarly, t0: cfg.upgradeFocusedInit)
                : (IRQ2BuildPlanner)new SpreadFocusedPlanner(nPlace: cfg.spreadFocusedCount);

            planner.Init(ctx);

            int guard = 0;
            while (planner.TryNextAction() && guard++ < 1000) {}

            // 4) 写一行 BUILD 阶段记录
            RunRecorder.CommitBuildPhase();

            Debug.Log($"[RQ2] {cfg.conditionLabel} | {cfg.buildPlan} planned. place={planner.Placements}, upg={planner.Upgrades}");
        }
    }
}
