using System.Collections.Generic;
using UnityEngine;

namespace RQ2
{
    public class SpreadFocusedPlanner : IRQ2BuildPlanner
    {
        private RQ2Context ctx;
        private int nPlace;     // 目标铺点数
        private readonly HashSet<MapCube> occupied = new();
        private int placements = 0, upgrades = 0, spent = 0;
        private int cursorPlace = 0;
        private bool done = false;

        public SpreadFocusedPlanner(int nPlace = 6) { this.nPlace = Mathf.Max(0, nPlace); }
        public void Init(RQ2Context ctx) { this.ctx = ctx; }

        public bool TryNextAction()
        {
            if (done) return false;

            // 1) 先铺满 nPlace
            while (placements < nPlace && cursorPlace < ctx.Slots.Count)
            {
                var slot = ctx.Slots[cursorPlace++];
                if (RQ2Common.TryPlace(slot, ctx.Turret, ref ctx.Budget, occupied))
                { placements++; spent = 1000 - ctx.Budget; return true; }
            }

            // 2) 仍有钱继续铺（不升级）
            while (cursorPlace < ctx.Slots.Count)
            {
                var slot = ctx.Slots[cursorPlace++];
                if (RQ2Common.TryPlace(slot, ctx.Turret, ref ctx.Budget, occupied))
                { placements++; spent = 1000 - ctx.Budget; return true; }
            }

            done = true; return false;
        }

        public bool IsDone => done;
        public int Placements => placements;
        public int Upgrades => upgrades; // 始终为 0（策略规定）
        public int GoldSpent => spent;
    }
}
