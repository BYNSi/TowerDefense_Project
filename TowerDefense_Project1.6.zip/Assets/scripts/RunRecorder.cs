using System.Globalization;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class RunRecorder
{
    private struct Row
    {
        public string datetime, map, condition, plan;
        public int seed, placements, upgrades, gold_spent;
        public string result; public int leaks; public float duration, totalDamage;
        public string phase; // BUILD / RESULT

        public static string Header =>
"datetime,map,condition,plan,seed,placements,upgrades,gold_spent,result,leaks,duration,totalDamage,phase";

        public string ToCsv() =>
$"{datetime},{map},{condition},{plan},{seed},{placements},{upgrades},{gold_spent}," +
$"{result},{leaks},{duration.ToString(CultureInfo.InvariantCulture)}," +
$"{totalDamage.ToString(CultureInfo.InvariantCulture)},{phase}";
    }

    private static string _csvPath;
    private static Row _row;
    private static bool _started;

    public static void StartNew(ExperimentConfig cfg, string csvOverride = null)
    {
        string file = string.IsNullOrEmpty(csvOverride) ? cfg.csvFileName : csvOverride;
        _csvPath = Path.Combine(Application.persistentDataPath, string.IsNullOrEmpty(file) ? "results.csv" : file);

        _row = new Row {
            datetime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
            map = SceneManager.GetActiveScene().name,
            condition = cfg != null ? cfg.conditionLabel : "",
            plan = cfg != null ? cfg.buildPlan.ToString() : "",
            seed = cfg != null ? cfg.randomSeed : 0,
            placements = 0, upgrades = 0, gold_spent = 0,
            result = "", leaks = -1, duration = -1f, totalDamage = -1f,
            phase = "BUILD"
        };

        EnsureHeader();
        _started = true;
        Debug.Log($"[RunRecorder] Start → {_csvPath}");
    }

    public static void StartNewManual(string condition, string plan, int seed, string csvFileName = "results.csv")
    {
        _csvPath = Path.Combine(Application.persistentDataPath, string.IsNullOrEmpty(csvFileName) ? "results.csv" : csvFileName);
        _row = new Row {
            datetime = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
            map = SceneManager.GetActiveScene().name,
            condition = condition, plan = plan, seed = seed,
            placements = 0, upgrades = 0, gold_spent = 0,
            result = "", leaks = -1, duration = -1f, totalDamage = -1f,
            phase = "BUILD"
        };
        EnsureHeader(); _started = true;
        Debug.Log($"[RunRecorder] Start(manual) → {_csvPath}");
    }

    public static void CountPlacement(int cost)
    { if (_started) { _row.placements += 1; _row.gold_spent += Mathf.Max(0, cost); } }

    public static void CountUpgrade(int cost)
    { if (_started) { _row.upgrades += 1; _row.gold_spent += Mathf.Max(0, cost); } }

    public static void CommitBuildPhase()
    { if (_started) { WriteLine(_row); Debug.Log($"[RunRecorder] BUILD ok: place={_row.placements}, upg={_row.upgrades}, spent={_row.gold_spent}"); } }

    public static void ReportWin(int leaks = 0, float duration = -1f, float totalDamage = -1f)
    { if (_started) { var r = _row; r.phase="RESULT"; r.result="WIN"; r.leaks=leaks; r.duration=duration; r.totalDamage=totalDamage; WriteLine(r); } }

    public static void ReportLose(int leaks = -1, float duration = -1f, float totalDamage = -1f)
    { if (_started) { var r = _row; r.phase="RESULT"; r.result="LOSE"; r.leaks=leaks; r.duration=duration; r.totalDamage=totalDamage; WriteLine(r); } }

    private static void EnsureHeader()
    {
        if (!File.Exists(_csvPath))
        {
            using var sw = new StreamWriter(_csvPath, append:false);
            sw.WriteLine(Row.Header);
        }
    }
    private static void WriteLine(Row r)
    { using var sw = new StreamWriter(_csvPath, append:true); sw.WriteLine(r.ToCsv()); }
}
