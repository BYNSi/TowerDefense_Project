using System.Collections.Generic;
using UnityEngine;

public class Waypoints : MonoBehaviour
{
    public static Waypoints Instance { get; private set; }

    private List<Transform> waypointList;
    private float[] prefix;

    private void Awake()
    {
        Instance = this;
        Init();
    }

    private void Init()
    {
        Transform[] transforms = transform.GetComponentsInChildren<Transform>();
        waypointList = new List<Transform>(transforms);
        waypointList.RemoveAt(0); 

        int n = waypointList.Count;
        prefix = new float[n];
        if (n > 0) prefix[0] = 0f;
        for (int i = 1; i < n; i++)
        {
            prefix[i] = prefix[i - 1] +
                        Vector3.Distance(waypointList[i - 1].position, waypointList[i].position);
        }
    }

    public int GetLength() => waypointList.Count;
    public Vector3 GetWaypoint(int index) => waypointList[index].position;

    public int Count => waypointList.Count;

    /// <summary>
    /// </summary>
    public float RemainingFromIndex(int idx)
    {
        int last = waypointList.Count - 1;
        if (idx >= last) return 0f;
        return prefix[last] - prefix[idx];
    }
}
