using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserTurret : Turret
{
    [Header("Laser Settings")]
    public float damagePerSecond = 60f;
    public LineRenderer lineRenderer;
    public Transform laserStartPoint;
    public GameObject laserEffectGo;

    protected override void Attack()
    {
        // 使用基类里实现的取目标（支持 Nearest / ClosestToExit）
        Transform target = GetTarget();

        if (target == null)
        {
            // 无目标：关闭可视化
            if (laserEffectGo != null && laserEffectGo.activeSelf) laserEffectGo.SetActive(false);
            if (lineRenderer != null && lineRenderer.enabled) lineRenderer.enabled = false;
            return;
        }

        // 有目标：开启特效并对准
        if (laserEffectGo != null)
        {
            if (!laserEffectGo.activeSelf) laserEffectGo.SetActive(true);
            laserEffectGo.transform.position = target.position;

            Vector3 lookAtPosition = transform.position;
            lookAtPosition.y = laserEffectGo.transform.position.y;
            laserEffectGo.transform.LookAt(lookAtPosition);
        }

        // 造成持续伤害 + 记录到日志
        var enemy = target.GetComponent<Enemy>();
        if (enemy != null)
        {
            float dealt = damagePerSecond * Time.deltaTime;
            enemy.TakeDamage(dealt);
            RunLogger.I?.AddDamage(dealt);   // ← 关键：累计伤害
        }

        // 绘制激光
        if (lineRenderer != null)
        {
            if (!lineRenderer.enabled) lineRenderer.enabled = true;
            Vector3 startPos = (laserStartPoint != null) ? laserStartPoint.position : transform.position;
            lineRenderer.SetPosition(0, startPos);
            lineRenderer.SetPosition(1, target.position);
        }
    }
}
