using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public int damage = 50;
    public float speed = 10f;
    public float hitDistance = 1.3f;         

    public GameObject bulletExplosionPrefab;

    private Transform target;
    private bool _hitOrDead = false;          

    private void Update()
    {
        if (_hitOrDead) return;

        if (target == null)
        {
            Dead(null);                        
            return;
        }

       
        transform.LookAt(target.position);
        transform.Translate(Vector3.forward * speed * Time.deltaTime);

     
        float dist = Vector3.Distance(transform.position, target.position);
        if (dist <= hitDistance)
        {
          
            var enemy = target.GetComponent<Enemy>();
            if (enemy != null)
            {
                enemy.TakeDamage(damage);
                RunLogger.I?.AddDamage(damage);
            }

            Dead(target);                   
        }
    }

    public void SetTarget(Transform _target)
    {
        target = _target;
    }

    private void Dead(Transform attachTo)
    {
        if (_hitOrDead) return;
        _hitOrDead = true;

        
        if (bulletExplosionPrefab != null)
        {
            GameObject fx = Instantiate(bulletExplosionPrefab, transform.position, Quaternion.identity);
            if (attachTo != null)
            {
                fx.transform.SetParent(attachTo, true);
            }
            Destroy(fx, 1f);
        }

        Destroy(gameObject);
    }
}
