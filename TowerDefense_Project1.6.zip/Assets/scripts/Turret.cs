using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret : MonoBehaviour
{
    public enum TargetingMode { Nearest, ClosestToExit }
    public static TargetingMode GlobalMode = TargetingMode.Nearest;

    [SerializeField]
    private List<GameObject> enemyList = new List<GameObject>();

    public float attackRate = 1f;                 
    public GameObject bulletPrefab;
    public Transform bulletPosition;

    private float nextAttackTime;
    private Transform head;

    protected virtual void Start()
    {
        head = transform.Find("head");
    }

    private void Update()
    {
        DirectionControl();
        Attack();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
           
            if (!enemyList.Contains(other.gameObject))
                enemyList.Add(other.gameObject);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Enemy"))
        {
            enemyList.Remove(other.gameObject);
        }
    }


    protected virtual void Attack()
    {
        if (Time.time < nextAttackTime) return;

        Transform target = GetTarget();
        if (target == null) return;

        GameObject go = Instantiate(bulletPrefab, bulletPosition.position, Quaternion.identity);
        var b = go.GetComponent<Bullet>();
        if (b != null) b.SetTarget(target);

        nextAttackTime = Time.time + attackRate;
    }


    public Transform GetTarget()
    {
        CleanEnemyList();
        if (enemyList.Count == 0) return null;

        return (GlobalMode == TargetingMode.Nearest)
            ? ChooseNearest()
            : ChooseClosestToExit();
    }

    private void CleanEnemyList()
    {
        for (int i = enemyList.Count - 1; i >= 0; i--)
        {
            if (enemyList[i] == null) enemyList.RemoveAt(i);
        }
    }

    private Transform ChooseNearest()
    {
        Transform best = null;
        float bestD = float.MaxValue;
        Vector3 p = transform.position;

        foreach (var go in enemyList)
        {
            if (go == null) continue;
            float d = Vector3.Distance(p, go.transform.position);
            if (d < bestD)
            {
                bestD = d;
                best = go.transform;
            }
        }
        return best;
    }


    private Transform ChooseClosestToExit()
    {
        Transform best = null;
        float bestR = float.MaxValue;

        foreach (var go in enemyList)
        {
            if (go == null) continue;
            var enemy = go.GetComponent<Enemy>();
            if (enemy == null) continue;
            float r = enemy.RemainingPathDistance();
            if (r < bestR)
            {
                bestR = r;
                best = go.transform;
            }
        }
        return best;
    }


    private void DirectionControl()
    {
        if (head == null) return;

        Transform target = GetTarget();
        if (target == null) return;

        Vector3 targetPosition = target.position;
        targetPosition.y = head.position.y;
        head.LookAt(targetPosition);
    }
}
