using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; // ← 加这一行

public class GameManager : MonoBehaviour
{
    // ===== Singleton =====
    public static GameManager Instance { get; private set; }

    // ===== References =====
    [Header("UI")]
    public GameEndUI gameEndUI;   // 在 Inspector 拖拽

    [Header("Experiment")]
    public ExperimentConfig config;  // 在 Inspector 拖 RQ1-Nearest / RQ1-Closest / RQ2-*

    // 防止重复结算（多次触发Win/Fail导致重复写CSV）
    private bool _ended = false;

    private void Awake()
    {
        Instance = this;
    }

    private void Start()
    {
        if (config != null)
        {
            Random.InitState(config.randomSeed);
            Application.targetFrameRate = 60;

            if (RunLogger.I == null)
                new GameObject("RunLogger").AddComponent<RunLogger>();
            RunLogger.I.Init(config.conditionLabel, config.csvFileName);

            Turret.GlobalMode = (Turret.TargetingMode)config.targetingMode;
            Debug.Log($"[GameManager] Mode={Turret.GlobalMode}, CSV={config.csvFileName}");
        }
        else
        {
            Debug.LogWarning("ExperimentConfig not assigned on GameManager (optional).");
        }
    }

    // ===== End States =====
    public void Fail()
    {
        if (_ended) return;
        _ended = true;

        if (EnemySpawner.Instance != null)
            EnemySpawner.Instance.StopSpawn();

        RunLogger.I?.FinalizeAndWrite("FAIL");
        if (gameEndUI != null) gameEndUI.Show("FAIL");
        else Debug.Log("FAIL");
    }

    public void Win()
    {
        if (_ended) return;
        _ended = true;

        RunLogger.I?.FinalizeAndWrite("WIN");
        if (gameEndUI != null) gameEndUI.Show("WIN");
        else Debug.Log("WIN");
    }

    public void OnRestar()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void OnMenu()
    {
        SceneManager.LoadScene(0);
    }
}
