using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    // ====== Movement along Waypoints ======
    // 下一目标路径点索引（你项目里就是这个名字）
    private int pointIndex = 0;
    // 正在前往的世界坐标
    private Vector3 targetPosition = Vector3.zero;
    public float speed = 10f;

    // ====== Combat / HP ======
    public float hp = 100f;
    private float maxHp = 0f;
    public GameObject explosionPrefab;
    private Slider hpSlider;

    // ====== Unity lifecycle ======
    private void Start()
    {
        maxHp = hp;

        // 找到自身或子物体上的 Slider（血条）
        hpSlider = GetComponentInChildren<Slider>();
        if (hpSlider != null)
        {
            hpSlider.value = 1f;
        }

        // 初始化第一个目标路径点
        if (Waypoints.Instance != null && Waypoints.Instance.GetLength() > 0)
        {
            targetPosition = Waypoints.Instance.GetWaypoint(pointIndex);
        }
        else
        {
            Debug.LogError("[Enemy] Waypoints not set in scene.");
        }
    }

    private void Update()
    {
        MoveAlongPath();
    }

    // ====== Path following ======
    private void MoveAlongPath()
    {
        if (Waypoints.Instance == null) return;

        // 朝当前目标点移动
        Vector3 dir = (targetPosition - transform.position);
        float distThisFrame = speed * Time.deltaTime;

        if (dir.magnitude <= distThisFrame)
        {
            // 抵达当前目标点 → 切换到下一个
            pointIndex++;
            if (pointIndex >= Waypoints.Instance.GetLength())
            {
                // 到达终点：记 leak、触发失败与收尾
                ReachExit();
                return;
            }
            targetPosition = Waypoints.Instance.GetWaypoint(pointIndex);
        }
        else
        {
            transform.Translate(dir.normalized * distThisFrame, Space.World);
        }
    }

    private void ReachExit()
    {
        // 统计一次漏怪
        RunLogger.I?.AddLeak();

        // 通知游戏失败（若你的流程不同，改为你的调用）
        if (GameManager.Instance != null)
            GameManager.Instance.Fail();

        // 敌人计数 -1
        if (EnemySpawner.Instance != null)
            EnemySpawner.Instance.DecreateEnemyCount();

        // 销毁自己
        Destroy(gameObject);
    }

    // ====== Death & Damage ======
    private void Die()
    {
        // 敌人计数 -1
        if (EnemySpawner.Instance != null)
            EnemySpawner.Instance.DecreateEnemyCount();

        // 爆炸效果
        if (explosionPrefab != null)
        {
            GameObject go = Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            Destroy(go, 1f);
        }

        Destroy(gameObject);
    }

    public void TakeDamage(float damage)
    {
        if (hp <= 0) return;
        hp -= damage;
        if (hpSlider != null && maxHp > 0f)
            hpSlider.value = Mathf.Clamp01(hp / maxHp);

        if (hp <= 0f)
        {
            Die();
        }
    }

    // ====== Progress-to-goal (for Closest-to-Exit) ======
    /// <summary>
    /// 剩余路径距离 = 当前位置到“下一个路径点”的直线距离
    ///             + 从该路径点到终点的累计段长（由 Waypoints.RemainingFromIndex 提供）
    /// </summary>
    public float RemainingPathDistance()
    {
        if (Waypoints.Instance == null) return 0f;

        int nextIdx = pointIndex;
        int n = Waypoints.Instance.GetLength();
        if (nextIdx >= n) return 0f;

        Vector3 nextPos = Waypoints.Instance.GetWaypoint(nextIdx);
        float toNext = Vector3.Distance(transform.position, nextPos);
        float rest = Waypoints.Instance.RemainingFromIndex(nextIdx); // 需要在 Waypoints 里已实现
        return toNext + rest;
    }
}
