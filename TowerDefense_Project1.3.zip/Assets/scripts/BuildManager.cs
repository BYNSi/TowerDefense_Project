using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;


public class BuildManager : MonoBehaviour
{
    public static BuildManager Instance {get;private set;}

    public TurretData StandardTurretData;
    public TurretData MissileTurretData;
    public TurretData LaserTurretData;

    public TurretData selectedTurretData;


    public TextMeshProUGUI moneyText;
    private Animator moneyTextAnim;
    private int money = 1000;
    

    private void Awake()
    {
        Instance = this;
         moneyTextAnim = moneyText.GetComponent<Animator>();
    }
   

   public void OnStandardSelected(bool isOn)
   {
    if(isOn)
    {
        selectedTurretData = StandardTurretData;
    }
   }

    public void OnMissileSelected(bool isOn)
   {
    if(isOn)
    {
        selectedTurretData = MissileTurretData;
    }
    
   }

   public void OnLaserSelected(bool isOn)
   {
    if(isOn)
    {
        selectedTurretData = LaserTurretData;
    }
   }

    public bool IsEnough(int need)
    {
        if(need <= money)
        {
            return true;

        }
        else
        {
            MoneyFlicker();
            return false;
        }

    }
    public void ChangeMoney(int value)
    {
        this.money += value;
        moneyText.text = "$" + money.ToString();
    }
    private void MoneyFlicker()
    {
        moneyTextAnim.SetTrigger("flicker");
    }
}
