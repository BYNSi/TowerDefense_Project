using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;


public class MapCube : MonoBehaviour
{
   
    private GameObject turretGo;
    private TurretData turretData;
    
    public GameObject buildEffect;

   private void  OnMouseDown()
   {
    if(EventSystem.current.IsPointerOverGameObject() == true) return;
    TurretData selectedTD = BuildManager.Instance.selectedTurretData;
    if(selectedTD == null || selectedTD.turretPrefab == null ) return;
    if(turretGo != null  ) return;

    BuildTurret(selectedTD);
   }

    private void BuildTurret(TurretData _turretData)
    {
        if(BuildManager.Instance.IsEnough(_turretData.cost)==false)
        {
            return;
        }
        BuildManager.Instance.ChangeMoney(- _turretData.cost);
        turretData = _turretData;
        turretGo = GameObject.Instantiate(_turretData.turretPrefab, transform.position, Quaternion.identity);
        GameObject go = GameObject.Instantiate(buildEffect,transform.position,Quaternion.identity);
        Destroy(go,2);
    }


}
