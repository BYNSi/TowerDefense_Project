using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;


public class MapCube : MonoBehaviour
{
   
    private GameObject turretGo;
    private TurretData turretData;
    
    public GameObject buildEffect;

    private Color normalColor;
    private bool isUpgrade = false;

    private void Start()
    {
        normalColor = GetComponent<MeshRenderer>().material.color;
    }

   private void  OnMouseDown()
   {
        if (EventSystem.current.IsPointerOverGameObject()) return;

            if (this.gameObject.tag == "Road")
            {
                return;
            }
        if(turretGo != null)
        {
            BuildManager.Instance.ShowUpgradeUI(this,transform.position,isUpgrade);
        }
        else
        {
            BuildTurret();
        }     
   }

    private void BuildTurret()
    {
        turretData = BuildManager.Instance.selectedTurretData;
        if(turretData == null || turretData.turretPrefab == null ) return;

        if(BuildManager.Instance.IsEnough(turretData.cost)==false)
        {
            return;
        }
        BuildManager.Instance.ChangeMoney(-turretData.cost);
        
        turretGo =  InstantiateTurret(turretData.turretPrefab);
    }
    private void OnMouseEnter()
    {
        if (this.gameObject.tag == "Road") return;
        if(turretGo == null && EventSystem.current.IsPointerOverGameObject() == false)
        {
            GetComponent<MeshRenderer>().material.color =normalColor*0.7f;
        }
    }

    private void OnMouseExit()
    {
        GetComponent<MeshRenderer>().material.color =normalColor;
    }

    public void OnTurretUpgrade()
    {
        if(BuildManager.Instance.IsEnough(turretData.costUpgrade))
        {
            isUpgrade = true;
            BuildManager.Instance.ChangeMoney(-turretData.costUpgrade);
            Destroy(turretGo);
            turretGo =  InstantiateTurret(turretData.turretUpgradePrefab);
            
        }
    }
    public void OnTurretDestroy()
    {
        Destroy(turretGo);
        turretGo = null;
        turretData = null;
        GameObject go = GameObject.Instantiate(buildEffect,transform.position,Quaternion.identity);
        Destroy(go,2);
    }
    private GameObject InstantiateTurret(GameObject prefab)
    {
        GameObject turretGo = GameObject.Instantiate(prefab,transform.position,Quaternion.identity);
        GameObject go = GameObject.Instantiate(buildEffect,transform.position,Quaternion.identity);
        Destroy(go,2);
        return turretGo;
    }
}
